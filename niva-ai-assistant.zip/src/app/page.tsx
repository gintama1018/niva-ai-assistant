import BatcompUI from "@/components/BatcompUI";

export default function Home() {
  return <BatcompUI />;
}
